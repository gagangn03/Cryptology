# Alternative Question: Read security_data.txt and use regular expressions
# to extract IP-address-like patterns, email addresses, session IDs, and
# hexadecimal sequences. Store the identified patterns in pattern_results.txt.

import re

with open("security_data.txt", "r") as file:
    text = file.read()

ip_pattern = r"\b(?:\d{1,3}\.){3}\d{1,3}\b"
email_pattern = r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"
session_pattern = r"\bSEC-\d{4}-\d{4}\b"
hex_pattern = r"\b[0-9A-Fa-f]+\b"

ips = re.findall(ip_pattern, text)
emails = re.findall(email_pattern, text)
sessions = re.findall(session_pattern, text)
hex_values = re.findall(hex_pattern, text)

with open("pattern_results.txt", "w") as file:
    file.write("IP-address-like patterns:\n")
    file.write("\n".join(ips) + "\n\n")
    file.write("Email addresses:\n")
    file.write("\n".join(emails) + "\n\n")
    file.write("Session IDs:\n")
    file.write("\n".join(sessions) + "\n\n")
    file.write("Hexadecimal sequences:\n")
    file.write("\n".join(hex_values) + "\n")

print("Patterns stored in pattern_results.txt")
