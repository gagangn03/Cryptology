# Alternative Question: Accept five lines of cryptology text and store them
# in input.txt. Read the file and determine lines, words, alphabetic characters,
# digits, spaces, and special characters. Convert text to uppercase and store
# the processed contents in processed.txt. Finally, display processed.txt.

with open("input.txt", "w") as file:
    for i in range(5):
        file.write(input(f"Enter line {i + 1}: ") + "\n")

with open("input.txt", "r") as file:
    text = file.read()

lines = len(text.splitlines())
words = len(text.split())
alphabets = sum(ch.isalpha() for ch in text)
digits = sum(ch.isdigit() for ch in text)
spaces = sum(ch.isspace() for ch in text)
special = sum(not ch.isalnum() and not ch.isspace() for ch in text)

print("Number of lines:", lines)
print("Number of words:", words)
print("Alphabetic characters:", alphabets)
print("Digits:", digits)
print("Spaces:", spaces)
print("Special characters:", special)

with open("processed.txt", "w") as file:
    file.write(text.upper())

print("\nProcessed contents:")
with open("processed.txt", "r") as file:
    print(file.read())
